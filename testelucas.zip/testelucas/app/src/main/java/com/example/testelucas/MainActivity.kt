package com.example.testelucas

import android.os.Bundle
import android.os.Parcelable
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.testelucas.ui.theme.TestelucasTheme
import com.google.firebase.analytics.FirebaseAnalytics.Event
import com.google.firebase.analytics.FirebaseAnalytics.Param
import com.google.firebase.analytics.FirebaseAnalytics


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TestelucasTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Greeting("Android")
                }
            }
        }
    }
}


@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    TestelucasTheme {
        Greeting("Android")
    }
    lateinit var mFirebaseAnalytics: FirebaseAnalytics
    val product1 = Bundle()
    product1.putString(Param.ITEM_NAME, "jegging")
    product1.putString(Param.ITEM_ID, "SKU_12345")
    product1.putDouble(Param.PRICE, 9.99)
    product1.putString(Param.ITEM_BRAND, "Gucci")
    product1.putString(Param.ITEM_CATEGORY, "calça")
    product1.putString(Param.ITEM_VARIANT, "Preto")
    product1.putLong(Param.QUANTITY, 1)

    val items = ArrayList<Parcelable>()
    items.add(product1);

    val ecommerceBundle = Bundle()
    ecommerceBundle.putParcelableArrayList("items", items)

    ecommerceBundle.putString(Param.TRANSACTION_ID, "T12345")
    ecommerceBundle.putString(Param.AFFILIATION, "Google Store")
    ecommerceBundle.putDouble(Param.VALUE, 12.21)
    ecommerceBundle.putDouble(Param.TAX, 1.11)
    ecommerceBundle.putDouble(Param.SHIPPING, 3.33)
    ecommerceBundle.putString(Param.CURRENCY, "USD")
    ecommerceBundle.putString(Param.COUPON, "SUMMER_FUN")

    mFirebaseAnalytics.logEvent( Event.PURCHASE, ecommerceBundle );
}

